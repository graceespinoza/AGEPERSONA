package MODELO;

import jakarta.persistence.*;
import org.hibernate.annotations.BatchSize;
import org.jetbrains.annotations.NotNull;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "persona")
public class AgePersona {
    @NotNull
    @Id
    @GeneratedValue
    @Size(min = 1, max = 10)
    @NotBlank(message = "Código de licenciatario para poder identificar el cliente por defecto dejar como 1")
    @Column(name="age_licenc_codigo")
    private  Long ageLicencCodigo;

    @NotNull
    @Id
    @GeneratedValue
    @Size(min = 1, max = 10)
    @NotBlank(message = "Código autoincrementable.")
    @Column(name="codigo")
    private Long codigo;

    @NotNull
    @Size(min=1, max = 50)
    @NotBlank(message = "Primer Nombre de persona")
    @Column(name="primer_nombre")
    private String primerNombre;


    @NotNull
    @Size(max = 50)
    @NotBlank(message = "Segundo nombre de persona")
    @Column(name="segundo_nombre")
    private String  segundoNombre;

    @NotNull
    @Size(min = 1, max = 50)
    @NotBlank(message = "Apellido paterno de persona")
    @Column(name="apellido_paterno")
    private String apellidoPaterno;

    @NotNull
    @Size(max = 50)
    @NotBlank(message = "Apellido materno de persona")
    @Column(name="apellido_materno")
    private  String apellidoMaterno;

    @NotNull
    @NotBlank(message = "Edad de persona")
    @Column(name="edad")
    private int edad;


    @Column(name="domicilio")
    @NotBlank(message = "Domicilio de persona")
    @Size(max = 500)
    private String domicilio;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$", message = "Formato de correo electrónico inválido")
    @Size(min = 1, max = 200)
    @NotBlank(message = "Correo electrónico de la persona")
    @Column(name="correo_electronico")
    private String correoElectronico;

    @NotNull
    @Size(min = 10, max = 13)
    @NotBlank(message =
            "Identificación de persona")
    @Column(name="identificacion")
    private String identificacion;

    public AgePersona(@NotNull Long ageLicencCodigo, @NotNull Long codigo, @NotNull String primerNombre, @NotNull String segundoNombre, @NotNull String apellidoPaterno, @NotNull String apellidoMaterno, @NotNull int edad, String domicilio, @NotNull String correoElectronico, @NotNull String identificacion) {
        this.ageLicencCodigo = ageLicencCodigo;
        this.codigo = codigo;
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.edad = edad;
        this.domicilio = domicilio;
        this.correoElectronico = correoElectronico;
        this.identificacion = identificacion;
    }

    public AgePersona() {

    }

    public Long getAgeLicencCodigo() {
        return ageLicencCodigo;
    }

    public void setAgeLicencCodigo(Long ageLicencCodigo) {
        this.ageLicencCodigo = ageLicencCodigo;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getPrimerNombre() {
        return primerNombre;
    }

    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public String getSegundoNombre() {
        return segundoNombre;
    }

    public void setSegundoNombre(String segundoNombre) {
        this.segundoNombre = segundoNombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }



}

package Implementacion;

import DAO.AgeDao;
import MODELO.AgePersona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/dao")
public class DaoImplemtacion {

    @Autowired
    private AgeDao agedao;

    @GetMapping("/all")
    public List<AgePersona> allperson(){

        return agedao.findAllAgePersona();
    }

    @PostMapping("/anadir")
    public String adAgePerson(@RequestBody AgePersona ageP){
        return agedao.savePersonAge(ageP);
    }

    @GetMapping("/find/{ageLicencCodigo}")
    public AgePersona getPersonById(@PathVariable Long ageLicencCodigo){

        return agedao.findById(ageLicencCodigo);
    }
}

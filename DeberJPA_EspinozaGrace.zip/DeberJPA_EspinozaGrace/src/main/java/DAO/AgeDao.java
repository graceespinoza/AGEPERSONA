package DAO;

import MODELO.AgePersona;

import java.util.List;

public interface AgeDao {
    List<AgePersona> findAllAgePersona(); //busco mi lista
    AgePersona findById(Long ageLicencCodigo);

    String savePersonAge(AgePersona Agedata);

    String updateAge(AgePersona newAgeData);

}

package repositorio;

import MODELO.AgePersona;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;




@Repository
public interface AgePersonaRepositorio extends JpaRepository<AgePersona, Long> {



}

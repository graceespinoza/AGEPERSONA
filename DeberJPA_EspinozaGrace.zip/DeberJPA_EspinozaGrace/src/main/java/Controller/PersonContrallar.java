package Controller;

import DAO.AgeDao;
import MODELO.AgePersona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import repositorio.AgePersonaRepositorio;

import java.util.List;

@Controller

public class PersonContrallar implements AgeDao {

    @Autowired
    private AgePersonaRepositorio agePersonaRepositorio;




    @Override
    public List<AgePersona> findAllAgePersona() {
        List<AgePersona> allAgePerson = agePersonaRepositorio.findAll();
        return allAgePerson;
    }

    @Override
    public AgePersona findById(Long ageLicencCodigo) {

        return agePersonaRepositorio.getOne(ageLicencCodigo);
    }

    @Override
    public String savePersonAge(AgePersona Agedata) {
        agePersonaRepositorio.save(Agedata);
        return "edad guardad";
    }

    @Override
    public String updateAge(AgePersona newAgeData) {
        String msg=null;
        if (newAgeData.getAgeLicencCodigo()!= null){
            agePersonaRepositorio.save(newAgeData);
            msg="Data updated";
        }
        else{
            msg="Error";}

        return msg;
    }


}

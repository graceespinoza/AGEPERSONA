package com.example.deberjpa_espinozagrace;

import MODELO.AgePersona;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeberJpaEspinozaGraceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeberJpaEspinozaGraceApplication.class, args);}
//        AgePersona person = new AgePersona(1l,
//                002L,
//                "Grace",
//                "Irene",
//                "Espinoza",
//                "Prieto",
//                22,
//                "Batallon del suburbio",
//                "ireneprieto111@hotmail.com",
//                "0953038395");
//
//    }



}




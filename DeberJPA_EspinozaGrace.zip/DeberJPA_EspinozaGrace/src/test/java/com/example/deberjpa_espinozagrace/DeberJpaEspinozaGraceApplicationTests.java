package com.example.deberjpa_espinozagrace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeberJpaEspinozaGraceApplicationTests {

    @Test
    void contextLoads() {
    }

}
